import { Users } from './../models/user';
import { Component, OnInit } from '@angular/core';
import {FormGroup, FormBuilder, Validators  } from '@angular/forms';
import { RegisterModel } from '../models/account-model';
import { AccountServicesService } from 'src/app/shared/services/account-services.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(
    private fb: FormBuilder,
    private service: AccountServicesService
    ) { }

  registerForm: FormGroup;
  regex: RegExp;
  users: Users[];
  checkbox1 = false;
  emailPattern = '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$';
  message: string;
  usersDataVar = {
    usersEmail: '',
    usersUserName: ''
  };

  reg: RegisterModel;
  validatMsg = {
    userName:{
      required: ' Please Write Your Username ',
      isValid:''
    },
    email:{
      required: ' Please Write Your Email ',
      notValid: 'Your Email is Not Valid ',
      isValid:''
    },
    fullName:{
      required: 'Please Write Your Full Name'
    },
    password:{
      required: 'Please Write Your Password',
      minLength: 'at least 6 character for password',
      isValid: ''
    },
    passwordConfirm:{
      required: 'Please Rewrite Your Password',
      minLength: 'at least 6 character for password',
      isMatch: 'your password not match'
    },
    userType:{
      required: ' Please Choose a User Type'
    }
  };

  ngOnInit(): void {
    this.message = '';
    this.users = [];
    this.reg = {
      userName: '',
      fullName: '',
      email: '',
      password: '',
      userType: '',
      isActive: this.checkbox1,
    };

    this.registerForm = this.fb.group({
      userName: [ '' , Validators.required],
      fullName: [ '' , Validators.required],
      email: [ '' , [Validators.required, Validators.pattern(this.emailPattern)]],
      password: [ '' , [Validators.required,  Validators.minLength(6)]],
      passwordConfirm: [ '' , [Validators.required,  Validators.minLength(6)]],
      userType: [ '' , Validators.required],
      isActive:[]
    });

    this.usersData();
  }

  register(){
    if (this.registerForm.valid) {
      this.validatRegisterModel();
      this.service.register(this.reg).subscribe(success =>{
        this.registerForm.reset();
        this.ngOnInit();
        this.message = ' Registeration Success...Open Your Email to Active Your Account';
      }, err => console.log(err));
    }
  }

  validatRegisterModel() {
    this.reg.userName = this.registerForm.value.userName;
    this.reg.fullName = this.registerForm.value.fullName;
    this.reg.email = this.registerForm.value.email;
    this.reg.password = this.registerForm.value.password;
    this.reg.userType = this.registerForm.value.userType;
    this.reg.isActive = this.registerForm.value.isActive;
  }

  isPasswordMatched(){
    if (this.registerForm.value.password !== '' && this.registerForm.value.passwordConfirm !== '') {
      if((this.registerForm.value.password !== this.registerForm.value.passwordConfirm) &&
        this.registerForm.value.password.length > 5 && this.registerForm.value.passwordConfirm.length > 5){
        return true;
      }
    }
    return false;
  }

  isPasswordValid(){
    const  pass = this.registerForm.value.password;
    if (pass !== '' && pass.length > 5) {
      this.regex = new RegExp('[a-z]');
      if (!this.regex.test(pass)) {
        this.validatMsg.password.isValid = 'Your Password Must Be Contains lowercase characters.';
        return false;
      }
      this.regex = new RegExp('[A-Z]');
      if (!this.regex.test(pass)) {
        this.validatMsg.password.isValid = 'Your Password Must Be Contains uppercase characters.';
        return false;
      }
      this.regex = new RegExp('[~!@#$%^&*()+<>{}.]');
      if (!this.regex.test(pass)) {
        this.validatMsg.password.isValid = 'Your Password Must Be Contains Special characters.';
        return false;
      }
      this.regex = new RegExp('[0-9]');
      if (!this.regex.test(pass)) {
        this.validatMsg.password.isValid = 'Your Password Must Be Contains Number.';
        return false;
      }
    }
    return true;
  }

  isUserNameExist(){
    for(const name of this.usersDataVar.usersUserName){
      const userName = this.registerForm.value.userName;
      if(name === userName){
        this.validatMsg.userName.isValid = 'This Username is already taken';
        return true;
      }
    }
    return false;
  }
  isEmailExist(){
    for(const em of this.usersDataVar.usersEmail){
      const email = this.registerForm.value.email;
      if(em === email){
        this.validatMsg.email.isValid = 'This Email is already taken';
        return true;
      }
    }
    return false;
  }

  usersData(){
    this.service.GetUsersDataForCheck().subscribe(list => {
      this.usersDataVar.usersUserName = list[0],
      this.usersDataVar.usersEmail = list[1]
    });
  }
}
