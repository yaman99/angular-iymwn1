export class RegisterModel {
  userName: string;
  fullName: string;
  password: string;
  email: string;
  userType: string;
  isActive: boolean;
}
export class LoginModel{
  password: string;
  email: string;
}
