import { AuthService } from '../../shared/services/auth.service';
import { LoginModel } from './../models/account-model';
import { AccountServicesService } from 'src/app/shared/services/account-services.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { connectableObservableDescriptor } from 'rxjs/internal/observable/ConnectableObservable';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(
    private fb: FormBuilder,
    private service: AuthService,
    private route: Router
    ) { }


  loginForm: FormGroup;
  log: LoginModel;
  message: string;
  userProfiledata: any;

  validatMsg = {
    email: {
      required: ' Please Write Your Email ',
      notValid: 'Your Email is Not Valid ',
      isValid: ''
    },
    password: {
      required: 'Please Write Your Password',
      minLength: 'at least 6 character for password',
      isValid: ''
    }
  };

  ngOnInit(): void {

    this.log = {
      email: '',
      password: ''
    };

    this.loginForm = this.fb.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });
    if (localStorage.getItem('token') != null) {
      this.route.navigate(['home']);
    } else {
      this.route.navigate(['login']);
    }

  }

  login() {
    if (this.loginForm.valid) {
        this.validatLoginModel();
        this.service.Login(this.log).subscribe(x => {
        if (this.service.isAdmin()) {
          this.route.navigate(['dashboard']);
        } else {
          this.route.navigate(['home']);
        }
        }, err => {
          if (err.status === 401) {
            this.message = 'Email is not confirmed yet!!..Check Your Email';
          } else if (err.status === 400) {
            this.message = 'username or password is incorrect';
          } else if (err.status === 500) {
            this.message = 'something wrong..try again later';
          }
          console.log(err);
        });
    }
  }

  validatLoginModel() {
    this.log.email = this.loginForm.value.email;
    this.log.password = this.loginForm.value.password;
  }
}
