import { LoginComponent } from './Account/login/login.component';
import { HomeComponent } from './home/home.component';


import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './shared/guards/auth.guard';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RegisterComponent } from './Account/register/register.component';



const routes: Routes = [
    {path: '', redirectTo:'home' , pathMatch: 'full'},
    {path: 'home', component : HomeComponent},
    {path: 'dashboard', component : DashboardComponent, canActivate:[AuthGuard], data: {premittedRoles: ['Admin']}},
];

@NgModule({
  imports: [RouterModule.forRoot(
    routes,
    { enableTracing: false }
    )
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
