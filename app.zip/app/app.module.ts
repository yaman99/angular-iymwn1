import { httpInterceptorProviders } from './shared/interceptors';
import { ErrorInterceptor } from './shared/interceptors/error.interceptor';
import { AuthService } from './shared/services/auth.service';
import { AccountServicesService } from 'src/app/shared/services/account-services.service';
import { HomeModule } from './home/home.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { RegisterComponent } from './Account/register/register.component';
import { LoginComponent } from './Account/login/login.component';
import { NavMenuComponent } from './shared/Layout/nav-menu/nav-menu.component';
import { FooterMenuComponent } from './shared/Layout/footer-menu/footer-menu.component';
import { AppRoutingModule } from './app-routing.module';
import { AccountModule } from './Account/account.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HomeComponent } from './home/home.component';
import { AuthInterceptor } from './shared/interceptors/auth.interceptor';
import { NavMenuDashboardComponent } from './shared/Layout/nav-menu-dashboard/nav-menu-dashboard.component';


@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    NavMenuComponent,
    FooterMenuComponent,
    DashboardComponent,
    HomeComponent,
    NavMenuDashboardComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AccountModule,
    DashboardModule,
    HomeModule,
    FormsModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    HttpClientModule,

  ],
  exports:[NavMenuComponent,NavMenuDashboardComponent],
  providers: [
    AccountServicesService,
    AuthService,
    httpInterceptorProviders
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
