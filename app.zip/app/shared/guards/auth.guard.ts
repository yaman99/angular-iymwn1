import { AuthService } from '../services/auth.service';
import { AccountServicesService } from 'src/app/shared/services/account-services.service';
import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
  Router
} from '@angular/router';
import { Observable, from } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private route: Router, private service: AuthService) {}

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | boolean {
    if (!this.service.isAuthenticated()) {
      return from(this.route.navigate(['login']));
    }

    const permittedRoles = next.data.premittedRoles as string[];
    if (permittedRoles) {
       if(this.service.hasRole(permittedRoles)){
         return true;
       } else{
         this.route.navigate(['home']);
       }
    }
    return true;
  }
}
