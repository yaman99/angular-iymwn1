import { environment } from '../../../environments/environment';
import { Users } from '../../Account/models/user';
import { Injectable } from '@angular/core';
import { RegisterModel } from '../../Account/models/account-model';
import { LoginModel } from '../../Account/models/account-model';
import { Observable, forkJoin, of, BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { tap, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AccountServicesService {

  constructor(private http: HttpClient) { }

  HTTP_URL = environment.HTTP_URL;
  headers={
    headers: new HttpHeaders({
      'Content-Type':'application/json'
    })
  }


  register(reg: RegisterModel): Observable<RegisterModel> {
    return this.http.post<RegisterModel>(this.HTTP_URL + 'ApplicationUser/Register' , reg).pipe();
  }

  Login(log: LoginModel): Observable<any> {
    return this.http.post<any>(this.HTTP_URL + 'ApplicationUser/Login' ,
    log);
  }


  GetUserProfileData(){
    return this.http.get(this.HTTP_URL + 'UserProfile/GetUserProfile');
  }


  public GetUsersDataForCheck(): Observable<any[]>{
    const UserNames = this.http.get<Users[]>(this.HTTP_URL + 'ApplicationUser/GetAllUserNames').pipe();
    const Emails = this.http.get<Users[]>(this.HTTP_URL + 'ApplicationUser/GetAllEmails').pipe();
    return forkJoin([UserNames, Emails]);
  }
}
