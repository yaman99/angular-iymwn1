import { LoginModel } from '../../Account/models/account-model';
import { Injectable } from '@angular/core';
import { tap } from 'rxjs/operators';
import { BehaviorSubject, Observable } from 'rxjs';
import { AccountServicesService } from './account-services.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private AccServ: AccountServicesService) {
    if (localStorage.getItem('token')) {
      this.setCurrentUser({
        role: this.getCurrentUserRoles(),
        isAuthenticated: true
      });
    } else {
      this.setCurrentUser({
        role: undefined,
        isAuthenticated: false
      });
    }
  }

  public currentUser$: BehaviorSubject<any> = new BehaviorSubject(undefined);

  private currentUser: any;

  Login(input: LoginModel): Observable<any> {
    return this.AccServ.Login(input).pipe(tap(x => this.onSuccessLogin(x.token)));
  }

  Logout() {
    localStorage.removeItem('token');
    this.setCurrentUser({
      role: undefined,
      isAuthenticated: false
    });
  }

  isAdmin() {
    if (this.getCurrentUserRoles() === 'Admin') {
      return true;
     }
    return false;
  }

  private onSuccessLogin(token: string) {
    localStorage.setItem('token', token);
    const payLoad = JSON.parse(window.atob(token.split('.')[1]));

    this.setCurrentUser({
      role: payLoad.role,
      isAuthenticated: true
    });
  }

  hasRole(rolesName: string[]): boolean {
    if (!this.currentUser || !this.currentUser.role) {
      return false;
    }

    return rolesName.some(x => {
      return x === this.getCurrentUserRoles();
    });
  }

  isAuthenticated(): boolean {
    return this.currentUser && this.currentUser.isAuthenticated;
  }

  private getCurrentUserRoles() {
    const token = localStorage.getItem('token');
    if (!token) {
      return undefined;
    }
    const payLoad = JSON.parse(window.atob(token.split('.')[1]));
    return payLoad.role;
  }

  private setCurrentUser(value: any) {
    this.currentUser = value;
    this.currentUser$.next(value);
  }
}
