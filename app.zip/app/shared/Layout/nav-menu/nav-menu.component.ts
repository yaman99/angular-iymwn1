import { AuthService } from '../../services/auth.service';
import { AccountServicesService } from 'src/app/shared/services/account-services.service';
import {
  Component,
  OnInit,
  ChangeDetectorRef,
  OnDestroy,
  HostListener
} from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-nav-menu',
  templateUrl: './nav-menu.component.html',
  styleUrls: ['./nav-menu.component.css']
})
export class NavMenuComponent implements OnInit {
  constructor(private route: Router, private authService: AuthService) {}

  title = 'StudyRow';
  public currentUser: any = {
    role: undefined,
    isAuthenticated: false
  };

  userRole: string;

  ngOnInit(): void {
    this.authService.currentUser$.subscribe(x => {
      this.currentUser = x;
    });
  }

  Logout() {
    this.authService.Logout();
    this.route.navigate(['login']);
  }

  hasRole(roleName: string) {
    return this.authService.hasRole([roleName]);
  }

  isAuthenticated() {
    return this.currentUser && this.currentUser.isAuthenticated;
  }
}
