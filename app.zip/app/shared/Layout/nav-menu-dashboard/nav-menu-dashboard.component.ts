import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-nav-menu-dashboard',
  templateUrl: './nav-menu-dashboard.component.html',
  styleUrls: ['./nav-menu-dashboard.component.css']
})
export class NavMenuDashboardComponent implements OnInit {

  constructor(private authService: AuthService, private route: Router) { }
  title = 'Admin Dashboard';

  ngOnInit(): void {
  }
  Logout() {
    this.authService.Logout();
    this.route.navigate(['login']);
  }

}
