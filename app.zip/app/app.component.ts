import { AccountServicesService } from 'src/app/shared/services/account-services.service';
import { Component, OnInit, HostListener } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  {

  constructor( private serv: AccountServicesService) {

  }
  title = 'StudyRow';

}
